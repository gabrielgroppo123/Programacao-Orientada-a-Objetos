package br.senac.sp.swingcrud.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    private static final String URL = "jdbc:mysql://localhost:3306/swingcrud";
    private static final String USER = "root";
    private static final String PASSWORD = "P@$$w0rd";

    public static Connection getConnection() throws SQLException{
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao conectar o banco de dados");
        }

    }
}
