package br.senac.sp.swingcrud.app;

import br.senac.sp.swingcrud.controller.ClienteController;
import br.senac.sp.swingcrud.dao.ClienteDao;
import br.senac.sp.swingcrud.dao.ConnectionFactory;
import br.senac.sp.swingcrud.view.ClienteView;

import java.sql.SQLException;

public class Main {
	public static void main(String[] args) {
		ClienteView view = new ClienteView();
		ClienteDao dao = new ClienteDao();
		view.setVisible(true);
		new ClienteController(view, dao);
	}
}
