package br.senac.sp.swingcrud.dao;

import br.senac.sp.swingcrud.model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDao {
    public void inserir(Cliente cliente){
        String sql = "INSERT INTO cliente (nome, email, endereco) values (?,?,?)";
        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getEmail());
            stmt.setString(3, cliente.getEndereco());
            stmt.executeUpdate();

        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    public List<Cliente> listar(){
        List<Cliente> lista = new ArrayList<Cliente>();
        String sql = "SELECT * FROM cliente ORDER BY nome";
        try (Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
        ) {
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getLong("id"));
                c.setNome(rs.getString("nome"));
                c.setEmail(rs.getString("email"));
                c.setEndereco(rs.getString("endereco"));
                lista.add(c);
            }
        }catch(Exception e){
            throw new RuntimeException(e);
        }
        return lista;
    }
    public List<Cliente> listar(String parametro){
        List<Cliente> lista = new ArrayList<Cliente>();
        String sql = "SELECT * FROM cliente where nome like ? ORDER BY nome";
        try (Connection conexao = ConnectionFactory.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery();
        ) {
            stmt.setString(1, "%" + parametro + "%");
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getLong("id"));
                c.setNome(rs.getString("nome"));
                c.setEmail(rs.getString("email"));
                c.setEndereco(rs.getString("endereco"));
                lista.add(c);
            }
        }catch(Exception e){
            throw new RuntimeException(e);
        }
        return lista;
    }
}
