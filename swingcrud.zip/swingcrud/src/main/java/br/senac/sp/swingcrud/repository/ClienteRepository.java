package br.senac.sp.swingcrud.repository;

import br.senac.sp.swingcrud.dao.ClienteDao;
import br.senac.sp.swingcrud.model.Cliente;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class ClienteRepository implements GenericRepository<Cliente>{

    private EntityManagerFactory factory;

    public ClienteRepository(EntityManagerFactory factory){
        this.factory = factory;
    }

    @Override
    public void inserir(Cliente objeto) {
        try (EntityManager manager = factory.createEntityManager()){
            manager.getTransaction().begin();
            manager.persist(objeto);
            manager.getTransaction().commit();
        }
        catch(Exception e){
            throw e;
        }
    }

    @Override
    public void atualizar(Cliente objeto) {
        try (EntityManager manager = factory.createEntityManager()){
            manager.getTransaction().begin();
            manager.merge(objeto);
            manager.getTransaction().commit();
        }
        catch(Exception e){
            throw e;
        }
    }

    @Override
    public void excluir(Long id) {

    }

    @Override
    public List<Cliente> listar() {
        try (EntityManager manager = factory.createEntityManager()){
            TypedQuery<Cliente> query = manager.createQuery("select c from Cliente c", Cliente.class);
            return query.getResultList();
        }
        catch(Exception e){
            throw e;
        }
    }
}
