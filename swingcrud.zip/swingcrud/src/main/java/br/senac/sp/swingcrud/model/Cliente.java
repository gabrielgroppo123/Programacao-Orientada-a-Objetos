package br.senac.sp.swingcrud.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Cliente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(columnDefinition = "varchar(200)", nullable = false)
	private String nome;
	@Column(nullable = false)
	private String email;
	private String endereco;
}
