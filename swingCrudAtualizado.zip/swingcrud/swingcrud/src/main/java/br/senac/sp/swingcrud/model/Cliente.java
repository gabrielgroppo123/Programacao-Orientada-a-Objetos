package br.senac.sp.swingcrud.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
public class Cliente {

	private Long id;
	private String nome;
	private String email;
	private String endereco;
}
