import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		ClienteController controller = new ClienteController();

		int opcao;

		do {
			System.out.println("\n=== CRUD CLIENTES ===");
			System.out.println("1 - Cadastrar");
			System.out.println("2 - Listar");
			System.out.println("3 - Atualizar");
			System.out.println("4 - Deletar");
			System.out.println("0 - Sair");
			System.out.print("Escolha: ");

			opcao = scanner.nextInt();
			scanner.nextLine(); // limpar buffer

			switch (opcao) {
				case 1:
					System.out.print("Nome: ");
					String nome = scanner.nextLine();

					System.out.print("Email: ");
					String email = scanner.nextLine();

					System.out.print("Endereço: ");
					String endereco = scanner.nextLine();

					controller.inserir(nome, email, endereco);
					System.out.println("Cliente cadastrado!");
					break;

				case 2:
					List<Cliente> clientes = controller.listar();
					for (Cliente c : clientes) {
						System.out.println(c);
					}
					break;

				case 3:
					System.out.print("ID do cliente: ");
					Long id = scanner.nextLong();
					scanner.nextLine();

					System.out.print("Novo nome: ");
					String novoNome = scanner.nextLine();

					System.out.print("Novo email: ");
					String novoEmail = scanner.nextLine();

					System.out.print("Novo endereço: ");
					String novoEndereco = scanner.nextLine();

					controller.atualizar(id, novoNome, novoEmail, novoEndereco);
					System.out.println("Cliente atualizado!");
					break;

				case 4:
					System.out.print("ID do cliente: ");
					Long idDelete = scanner.nextLong();

					controller.excluir(idDelete);
					System.out.println("Cliente deletado!");
					break;

			}

		} while (opcao != 0);

		scanner.close();
	}
}