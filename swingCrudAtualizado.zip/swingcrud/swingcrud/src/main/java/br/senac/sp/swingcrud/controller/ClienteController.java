public class ClienteController {

	private ClienteDao dao;

	public ClienteController() {
		this.dao = new ClienteDao();
	}

	public void inserir(String nome, String email, String endereco) {
		if (nome.trim().isEmpty()) {
			System.out.println("Nome obrigatório");
			return;
		}

		if (email.trim().isEmpty()) {
			System.out.println("Email obrigatório");
			return;
		}

		if (endereco.trim().isEmpty()) {
			System.out.println("Endereço obrigatório");
			return;
		}

		Cliente cliente = new Cliente();
		cliente.setNome(nome);
		cliente.setEmail(email);
		cliente.setEndereco(endereco);

		dao.inserir(cliente);
		System.out.println("Cliente cadastrado!");
	}

	public void listar() {
		List<Cliente> lista = dao.listar();

		if (lista.isEmpty()) {
			System.out.println("Nenhum cliente encontrado.");
			return;
		}

		for (Cliente c : lista) {
			System.out.println(c);
		}
	}

	public void atualizar(Long id, String nome, String email, String endereco) {
		Cliente cliente = new Cliente();
		cliente.setId(id);
		cliente.setNome(nome);
		cliente.setEmail(email);
		cliente.setEndereco(endereco);

		dao.atualizar(cliente);
		System.out.println("Cliente atualizado!");
	}

	public void excluir(Long id) {
		dao.excluir(id);
		System.out.println("Cliente excluído!");
	}
}