package br.senac.sp.guiarestaurante.models;

import lombok.Data;

import java.util.List;

@Data
public class Restaurante {
    private Long id;
    private String nome;
    private String cnpj;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String cep;
    private String telefone;
    private String horarioFunc;
    private TipoRestaurante tipo;
    private Preco preco;
    private FormasPagamento[] pagamento;
    private List<Avaliacao> avaliacoes;
    private List<PratoDestaque> destaques;
    private Servicos[] servicos;
    private String foto;

}
