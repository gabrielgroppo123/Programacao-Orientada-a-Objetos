package br.senac.sp.guiarestaurante.models;

public enum TipoUsuario {
    ADMINISTRADOR, CLIENTE
}
