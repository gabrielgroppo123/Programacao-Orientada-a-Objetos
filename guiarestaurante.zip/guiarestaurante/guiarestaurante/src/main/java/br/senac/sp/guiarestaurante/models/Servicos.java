package br.senac.sp.guiarestaurante.models;

public enum Servicos {
ACESSIBILIDADE, AR_CONDICIONADO, DELIVERY, ESPACO_KIDS, ESPACO_PET, ESTACIONAMENTO, TERRACO, VALLET, WIFI
}
