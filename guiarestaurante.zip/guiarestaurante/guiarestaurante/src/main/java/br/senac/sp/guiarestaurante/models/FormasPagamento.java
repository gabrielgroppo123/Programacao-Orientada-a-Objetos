package br.senac.sp.guiarestaurante.models;

public enum FormasPagamento {
    CREDITO, DEBITO, DINHEIRO, INFLUENCER, PIX, VA, VR
}
