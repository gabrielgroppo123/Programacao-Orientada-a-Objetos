package br.senac.sp.guiarestaurante.models;

public enum Preco {
    BARATO("$"), MODERADO("$$"), CARO("$$$"), CARISSIMO("$$$$");

    String str;

    Preco(String str){
        this.str = str;
    }

    @Override
    public String toString(){
        return str;
    }
}
