package br.senac.sp.guiarestaurante.models;

import lombok.Data;



@Data
public class PratoDestaque {
    private Long id;
    private String nome;
    private TipoPrato tipo;
    private String descricao;
    private String foto;
    private Restaurante restaurante;
    private String avaliacao;
}