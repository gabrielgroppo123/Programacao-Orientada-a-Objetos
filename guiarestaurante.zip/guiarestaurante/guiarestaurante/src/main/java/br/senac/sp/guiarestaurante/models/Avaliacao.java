package br.senac.sp.guiarestaurante.models;

import lombok.Data;

import java.util.Calendar;

@Data
public class Avaliacao {
    private Long id;
    private String comentario;
    private Calendar data;
    private int nota;
    private Usuario usuario;
    private Restaurante restaurante;
    private PratoDestaque prato;
}
