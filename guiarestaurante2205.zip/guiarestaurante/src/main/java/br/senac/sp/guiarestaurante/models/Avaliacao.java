package br.senac.sp.guiarestaurante.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Data;

import java.rmi.AccessException;
import java.util.Calendar;

@Data
@Entity
public class Avaliacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String comentario;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private Calendar data;
    private int nota;
    @ManyToOne
    private Usuario usuario;
    @ManyToOne
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Restaurante restaurante;
    @ManyToOne(optional = true)
    private PratoDestaque prato;
}
