package br.senac.sp.guiarestaurante.service;

import br.senac.sp.guiarestaurante.models.TipoPrato;
import br.senac.sp.guiarestaurante.repository.TipoPratoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TipoPratoService {
    private final TipoPratoRepository repository;

    public TipoPratoService(TipoPratoRepository rep) {
        this.repository = rep;
    }

    public void excluir(Long id){
        TipoPrato tipoprato = buscarPorId(id);
        repository.delete(tipoprato);
    }

    public TipoPrato atualizar(Long id, TipoPrato tipoprato){
        tipoprato.setId(id);
        return repository.save(tipoprato);
    }

    public TipoPrato inserir(TipoPrato tipoprato){
        return repository.save(tipoprato);
    }

    public TipoPrato buscarPorId(Long id){
        Optional<TipoPrato> busca = repository.findById(id);
        if (busca.isPresent()){
            return busca.get();
        }
        return null;
    }

    public Page<TipoPrato> listarTodos(Pageable pageable){
        return repository.findAll(pageable);
    }
}
