package br.senac.sp.guiarestaurante.controller;
import br.senac.sp.guiarestaurante.models.Erro;
import br.senac.sp.guiarestaurante.models.TipoPrato;
import br.senac.sp.guiarestaurante.service.TipoPratoService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;

@RestController
@RequestMapping("/tipoprato")
public class TipoPratoController {

    private final TipoPratoService service;

    public TipoPratoController(TipoPratoService serv){
        this.service = serv;
    }
    @PutMapping("/{id}")
    public ResponseEntity<TipoPrato> atualizar(@PathVariable("id") Long id, @RequestBody TipoPrato tipoprato){
        TipoPrato tipoAtualizado = service.atualizar(id, tipoprato);
        return ResponseEntity.ok(tipoAtualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<Object> inserir(@RequestBody TipoPrato tipoprato){
        try{
            TipoPrato salvo = service.inserir(tipoprato);
            //retornar codigo 201,
            // no header: devolver a location do recurso gerado
            // e no corpo: o recurso gerado
            return ResponseEntity.created(URI.create("/tipoprato/" + salvo.getId())).body(salvo);
        }
        catch (DataIntegrityViolationException e){
            Erro erro = Erro.builder().status(HttpStatus.BAD_REQUEST).mensagem("Posivel registro duplicado").exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
        catch (Exception e){
            Erro erro = Erro.builder().status(HttpStatus.INTERNAL_SERVER_ERROR).mensagem("Erro: " + e.getMessage()).exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoPrato> buscar(@PathVariable ("id") Long id){
        TipoPrato tipoprato = service.buscarPorId(id);
        if (tipoprato != null){
            return ResponseEntity.ok(tipoprato);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<Page<TipoPrato>> listar(@PageableDefault(page = 0, size = 10, sort = "nome", direction = Sort.Direction.ASC) Pageable pageable){
        Page<TipoPrato>page = service.listarTodos(pageable);
        if (page.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(page);
    }
}
