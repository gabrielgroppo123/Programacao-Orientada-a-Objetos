package br.senac.sp.guiarestaurante.models;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
@Builder
@JsonPropertyOrder({"status", "mensagem", "exception"})
public class Erro {
    private HttpStatus status;
    private String mensagem;
    private String exception;
}
