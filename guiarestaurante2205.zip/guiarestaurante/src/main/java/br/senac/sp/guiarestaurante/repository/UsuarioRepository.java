package br.senac.sp.guiarestaurante.repository;
import br.senac.sp.guiarestaurante.models.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    public Usuario findByNome(String nome);

    @Query("select usuario from Usuario usuario where usuario.nome like %:p% order by usuario.nome asc")
    public List<Usuario> buscarUsuarios(@Param("p")String parametro);
}
