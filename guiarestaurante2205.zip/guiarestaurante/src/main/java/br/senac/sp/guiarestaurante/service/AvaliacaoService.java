package br.senac.sp.guiarestaurante.service;

import br.senac.sp.guiarestaurante.models.Avaliacao;
import br.senac.sp.guiarestaurante.repository.AvaliacaoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AvaliacaoService {
    private final AvaliacaoRepository repository;

    public AvaliacaoService(AvaliacaoRepository rep) {
        this.repository = rep;
    }

    public void excluir(Long id){
        Avaliacao avaliacao = buscarPorId(id);
        repository.delete(avaliacao);
    }

    public Avaliacao atualizar(Long id, Avaliacao tipo){
        tipo.setId(id);
        return repository.save(tipo);
    }

    public Avaliacao inserir(Avaliacao avaliacao){
        return repository.save(avaliacao);
    }

    public Avaliacao buscarPorId(Long id){
        Optional<Avaliacao> busca = repository.findById(id);
        if (busca.isPresent()){
            return busca.get();
        }
        return null;
    }

    public Page<Avaliacao> listarTodos(Pageable pageable){
        return repository.findAll(pageable);
    }
}
