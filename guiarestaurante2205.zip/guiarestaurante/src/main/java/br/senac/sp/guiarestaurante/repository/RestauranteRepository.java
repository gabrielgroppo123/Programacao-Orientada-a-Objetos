package br.senac.sp.guiarestaurante.repository;
import br.senac.sp.guiarestaurante.models.Restaurante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
public interface RestauranteRepository extends JpaRepository<Restaurante, Long> {
    public Restaurante findByNome(String nome);

    @Query("select restaurante from Restaurante restaurante where restaurante.nome like %:p% order by restaurante.nome asc")
    public List<Restaurante> buscarRestaurantes(@Param("p")String parametro);
}
