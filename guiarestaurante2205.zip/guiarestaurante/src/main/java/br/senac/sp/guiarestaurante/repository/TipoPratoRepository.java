package br.senac.sp.guiarestaurante.repository;

import br.senac.sp.guiarestaurante.models.TipoPrato;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TipoPratoRepository extends JpaRepository<TipoPrato, Long>  {
    public TipoPrato findByNome(String nome);

    @Query("select tipoprato from TipoPrato tipoprato where tipoprato.nome like %:p% order by tipoprato.nome asc")
    public List<TipoPrato> buscarTipos(@Param("p")String parametro);
}
