package br.senac.sp.guiarestaurante.models;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
public class Restaurante {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    @Column(unique = true)
    private String cnpj;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;
    private String cidade;
    private String estado;
    private String cep;
    private String telefone;
    private String horarioFunc;
    @ManyToOne()
    private TipoRestaurante tipo;
    private Preco preco;
    private FormasPagamento[] pagamento;
    private Servicos[] servicos;
    private String foto;
    @OneToMany(mappedBy = "restaurante")
    private List<Avaliacao> avaliacoes;
    @OneToMany(mappedBy = "restaurante")
    private List<PratoDestaque> destaques;

}
