package br.senac.sp.guiarestaurante.controller;
import br.senac.sp.guiarestaurante.models.Erro;
import br.senac.sp.guiarestaurante.models.Usuario;
import br.senac.sp.guiarestaurante.service.UsuarioService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService serv){
        this.service = serv;
    }
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> atualizar(@PathVariable("id") Long id, @RequestBody Usuario usuario){
        Usuario usuarioAtualizado = service.atualizar(id, usuario);
        return ResponseEntity.ok(usuarioAtualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<Object> inserir(@RequestBody Usuario usuario){
        try{
            Usuario salvo = service.inserir(usuario);
            //retornar codigo 201,
            // no header: devolver a location do recurso gerado
            // e no corpo: o recurso gerado
            return ResponseEntity.created(URI.create("/usuario/" + salvo.getId())).body(salvo);
        }
        catch (DataIntegrityViolationException e){
            Erro erro = Erro.builder().status(HttpStatus.BAD_REQUEST).mensagem("Posivel registro duplicado").exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
        catch (Exception e){
            Erro erro = Erro.builder().status(HttpStatus.INTERNAL_SERVER_ERROR).mensagem("Erro: " + e.getMessage()).exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> buscar(@PathVariable ("id") Long id){
        Usuario usuario = service.buscarPorId(id);
        if (usuario != null){
            return ResponseEntity.ok(usuario);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<Page<Usuario>> listar(@PageableDefault(page = 0, size = 10, sort = "nome", direction = Sort.Direction.ASC) Pageable pageable){
        Page<Usuario>page = service.listarTodos(pageable);
        if (page.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(page);
    }
}
