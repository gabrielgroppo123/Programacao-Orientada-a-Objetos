package br.senac.sp.guiarestaurante.service;
import br.senac.sp.guiarestaurante.models.Restaurante;
import br.senac.sp.guiarestaurante.repository.RestauranteRepository;
import br.senac.sp.guiarestaurante.repository.UsuarioRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RestauranteService {
    private final RestauranteRepository repository;

    public RestauranteService(RestauranteRepository  rep){
        this.repository = rep;
    }

    public void excluir(Long id){
        Restaurante restaurante = buscarPorId(id);
        repository.delete(restaurante);
    }

    public Restaurante atualizar(Long id, Restaurante restaurante){
        restaurante.setId(id);
        return repository.save(restaurante);
    }

    public Restaurante inserir(Restaurante restaurante){
        return repository.save(restaurante);
    }

    public Restaurante buscarPorId(Long id){
        Optional<Restaurante> busca = repository.findById(id);
        if (busca.isPresent()){
            return busca.get();
        }
        return null;
    }

    public Page<Restaurante> listarTodos(Pageable pageable){
        return repository.findAll(pageable);
    }
}
