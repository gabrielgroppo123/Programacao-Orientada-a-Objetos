package br.senac.sp.guiarestaurante.repository;
import br.senac.sp.guiarestaurante.models.Avaliacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
public interface AvaliacaoRepository extends JpaRepository<Avaliacao, Long> {
    public Avaliacao findByComentario(String comentario);

    @Query("select avaliacao from Avaliacao avaliacao where avaliacao.comentario like %:p% order by avaliacao.comentario asc")
    public List<Avaliacao> buscarAvaliacoes(@Param("p")String parametro);
}
