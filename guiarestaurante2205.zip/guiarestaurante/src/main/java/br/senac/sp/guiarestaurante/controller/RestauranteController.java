package br.senac.sp.guiarestaurante.controller;
import br.senac.sp.guiarestaurante.models.Erro;
import br.senac.sp.guiarestaurante.models.Restaurante;
import br.senac.sp.guiarestaurante.service.RestauranteService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;

@RestController
@RequestMapping("/restaurante")
public class RestauranteController {

    private final RestauranteService service;

    public RestauranteController(RestauranteService serv){
        this.service = serv;
    }
    @PutMapping("/{id}")
    public ResponseEntity<Restaurante> atualizar(@PathVariable("id") Long id, @RequestBody Restaurante restaurante){
        Restaurante restAtualizado = service.atualizar(id, restaurante);
        return ResponseEntity.ok(restAtualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<Object> inserir(@RequestBody Restaurante restaurante){
        try{
            Restaurante salvo = service.inserir(restaurante);
            //retornar codigo 201,
            // no header: devolver a location do recurso gerado
            // e no corpo: o recurso gerado
            return ResponseEntity.created(URI.create("/restaurante/" + salvo.getId())).body(salvo);
        }
        catch (DataIntegrityViolationException e){
            Erro erro = Erro.builder().status(HttpStatus.BAD_REQUEST).mensagem("Posivel registro duplicado").exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
        catch (Exception e){
            Erro erro = Erro.builder().status(HttpStatus.INTERNAL_SERVER_ERROR).mensagem("Erro: " + e.getMessage()).exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Restaurante> buscar(@PathVariable ("id") Long id){
        Restaurante restaurante = service.buscarPorId(id);
        if (restaurante != null){
            return ResponseEntity.ok(restaurante);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<Page<Restaurante>> listar(@PageableDefault(page = 0, size = 10, sort = "nome", direction = Sort.Direction.ASC) Pageable pageable){
        Page<Restaurante>page = service.listarTodos(pageable);
        if (page.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(page);
    }
}
