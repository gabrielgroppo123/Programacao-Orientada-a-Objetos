package br.senac.sp.guiarestaurante.controller;
import br.senac.sp.guiarestaurante.models.Erro;
import br.senac.sp.guiarestaurante.models.Avaliacao;
import br.senac.sp.guiarestaurante.service.AvaliacaoService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;

@RestController
@RequestMapping("/avaliacao")
public class AvaliacaoController {

    private final AvaliacaoService service;

    public AvaliacaoController(AvaliacaoService serv){
        this.service = serv;
    }
    @PutMapping("/{id}")
    public ResponseEntity<Avaliacao> atualizar(@PathVariable("id") Long id, @RequestBody Avaliacao avaliacao){
        Avaliacao avaliacaoAtualizada = service.atualizar(id, avaliacao);
        return ResponseEntity.ok(avaliacao);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id){
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<Object> inserir(@RequestBody Avaliacao avaliacao){
        try{
            Avaliacao salvo = service.inserir(avaliacao);
            //retornar codigo 201,
            // no header: devolver a location do recurso gerado
            // e no corpo: o recurso gerado
            return ResponseEntity.created(URI.create("/avaliacao/" + salvo.getId())).body(salvo);
        }
        catch (DataIntegrityViolationException e){
            Erro erro = Erro.builder().status(HttpStatus.BAD_REQUEST).mensagem("Posivel registro duplicado").exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
        catch (Exception e){
            Erro erro = Erro.builder().status(HttpStatus.INTERNAL_SERVER_ERROR).mensagem("Erro: " + e.getMessage()).exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Avaliacao> buscar(@PathVariable ("id") Long id){
        Avaliacao avaliacao = service.buscarPorId(id);
        if (avaliacao != null){
            return ResponseEntity.ok(avaliacao);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<Page<Avaliacao>> listar(@PageableDefault(page = 0, size = 10, sort = "nome", direction = Sort.Direction.ASC) Pageable pageable){
        Page<Avaliacao>page = service.listarTodos(pageable);
        if (page.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(page);
    }
}
