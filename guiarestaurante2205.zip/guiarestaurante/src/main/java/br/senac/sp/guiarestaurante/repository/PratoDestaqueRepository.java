package br.senac.sp.guiarestaurante.repository;

import br.senac.sp.guiarestaurante.models.PratoDestaque;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PratoDestaqueRepository extends JpaRepository<PratoDestaque, Long>  {
    public PratoDestaque findByNome(String nome);

    @Query("select prato from PratoDestaque prato where prato.nome like %:p% order by prato.nome asc")
    public List<PratoDestaque> buscarPratos(@Param("p")String parametro);
}
