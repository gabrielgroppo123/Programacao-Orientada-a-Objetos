package prova01.model;

import java.util.Date;

public class Emprestimo {
    private Long id;
    private Date dataEmprestimo;
    private Date dataDevolucao;
    private Boolean ativo;
}
