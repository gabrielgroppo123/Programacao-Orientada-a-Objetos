package prova01.model;

import java.time.LocalDateTime;

public interface Pessoa {



    String getNome();
    void setNome(String nome);

    String getEmail();
    void setEmail(String email);

    LocalDateTime getDataCadastro();
    void setDataCadastro(LocalDateTime dataCadastro);
}
