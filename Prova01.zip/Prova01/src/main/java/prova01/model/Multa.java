package prova01.model;

import lombok.Data;

@Data
public class Multa {

    private Long id;
    private double valor;
    private String motivo;
    private Boolean paga;
}