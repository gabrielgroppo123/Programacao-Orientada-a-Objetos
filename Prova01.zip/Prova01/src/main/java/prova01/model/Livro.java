package prova01.model;
import lombok.Data;
@Data

public class Livro {
    private Long id;
    private String titulo;
    private int anoPublicacao;
    private String autor;
    private StatusLivro statusLivro;
}
