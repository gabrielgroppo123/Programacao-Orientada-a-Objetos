package prova01.model;

import java.time.LocalDateTime;


public class Bibliotecario implements Pessoa{
    private Long id;
    private String matricula;
    private double salario;
    private String turno;

    @Override
    public String getNome() {
        return "";
    }

    @Override
    public void setNome(String nome) {

    }

    @Override
    public String getEmail() {
        return "";
    }

    @Override
    public void setEmail(String email) {

    }

    @Override
    public LocalDateTime getDataCadastro() {
        return null;
    }

    @Override
    public void setDataCadastro(LocalDateTime dataCadastro) {

    }
}
