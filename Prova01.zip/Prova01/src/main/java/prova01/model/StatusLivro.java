package prova01.model;
public enum StatusLivro {
    RESERVADO, EMPRESTADO, DISPONIVEL;
}


