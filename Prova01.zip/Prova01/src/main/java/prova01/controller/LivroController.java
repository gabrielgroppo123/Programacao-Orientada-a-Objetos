package prova01.controller;
import prova01.dao.LivroDao;
import prova01.model.Livro;
import prova01.model.StatusLivro;

import java.util.List;

public class LivroController {

    private LivroDao dao;

    public LivroController() {
        this.dao = new LivroDao();
    }

    public void inserir(String titulo, int anoPublicacao, String autor, String status) {

        if (titulo.trim().isEmpty()) {
            System.out.println("Título obrigatório");
            return;
        }

        if (autor.trim().isEmpty()) {
            System.out.println("Autor obrigatório");
            return;
        }

        StatusLivro statusLivro;
        try {
            statusLivro = StatusLivro.valueOf(status.toUpperCase());
        } catch (Exception e) {
            System.out.println("Status inválido! Use: DISPONIVEL, EMPRESTADO ou RESERVADO");
            return;
        }

        Livro livro = new Livro();
        livro.setTitulo(titulo);
        livro.setAnoPublicacao(anoPublicacao);
        livro.setAutor(autor);
        livro.setStatusLivro(statusLivro);

        dao.inserir(livro);
        System.out.println("Livro cadastrado!");
    }

    public void listar() {
        List<Livro> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("Nenhum livro encontrado.");
            return;
        }

        for (Livro l : lista) {
            System.out.println(l);
        }
    }

    public void listar(String parametro) {
        List<Livro> lista = dao.listar(parametro);

        if (lista.isEmpty()) {
            System.out.println("Nenhum livro encontrado com esse título.");
            return;
        }

        for (Livro l : lista) {
            System.out.println(l);
        }
    }

    public void atualizar(Long id, String titulo, int anoPublicacao, String autor, String status) {

        StatusLivro statusLivro;
        try {
            statusLivro = StatusLivro.valueOf(status.toUpperCase());
        } catch (Exception e) {
            System.out.println("Status inválido!");
            return;
        }

        Livro livro = new Livro();
        livro.setId(id);
        livro.setTitulo(titulo);
        livro.setAnoPublicacao(anoPublicacao);
        livro.setAutor(autor);
        livro.setStatusLivro(statusLivro);

        dao.atualizar(livro);
        System.out.println("Livro atualizado!");
    }

    public void excluir(Long id) {
        dao.excluir(id);
        System.out.println("Livro excluído!");
    }
}