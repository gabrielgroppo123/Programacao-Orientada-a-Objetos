package prova01.controller;
import prova01.dao.MultaDao;
import prova01.model.Multa;

import java.util.List;

public class MultaController {

    private MultaDao dao;

    public MultaController() {
        this.dao = new MultaDao();
    }

    public void inserir(double valor, String motivo, Boolean paga) {

        if (valor <= 0) {
            System.out.println("Valor da multa deve ser maior que zero.");
            return;
        }

        if (motivo.trim().isEmpty()) {
            System.out.println("Motivo obrigatório.");
            return;
        }

        Multa multa = new Multa();
        multa.setValor(valor);
        multa.setMotivo(motivo);
        multa.setPaga(paga);

        dao.inserir(multa);
        System.out.println("Multa cadastrada!");
    }

    public void listar() {
        List<Multa> lista = dao.listar();

        if (lista.isEmpty()) {
            System.out.println("Nenhuma multa encontrada.");
            return;
        }

        for (Multa m : lista) {
            System.out.println(m);
        }
    }

    public void listar(String parametro) {
        List<Multa> lista = dao.listar(parametro);

        if (lista.isEmpty()) {
            System.out.println("Nenhuma multa encontrada com esse motivo.");
            return;
        }

        for (Multa m : lista) {
            System.out.println(m);
        }
    }

    public void atualizar(Long id, double valor, String motivo, Boolean paga) {

        if (valor <= 0) {
            System.out.println("Valor da multa deve ser maior que zero.");
            return;
        }

        if (motivo.trim().isEmpty()) {
            System.out.println("Motivo obrigatório.");
            return;
        }

        Multa multa = new Multa();
        multa.setId(id);
        multa.setValor(valor);
        multa.setMotivo(motivo);
        multa.setPaga(paga);

        dao.atualizar(multa);
        System.out.println("Multa atualizada!");
    }

    public void excluir(Long id) {
        dao.excluir(id);
        System.out.println("Multa excluída!");
    }
}