package prova01.app;

import prova01.controller.LivroController;
import prova01.controller.MultaController;

public class Main {
    public static void main(String[] args) {

        LivroController livro = new LivroController();
        MultaController multa = new MultaController();

        livro.inserir("Java Básico", 2020, "Gabriel", "DISPONIVEL");
        livro.inserir("Swift Básico", 2010, "guilherme", "DISPONIVEL");
        System.out.println("Lista de livros:");
        livro.listar();
        livro.atualizar(1L, "Java Avançado", 2022, "Gabriel", "EMPRESTADO");
        System.out.println("Lista após update:");
        livro.listar();
        livro.excluir(1L);
        System.out.println("Lista de livros:");
        livro.listar();

        multa.inserir(102.58, "Não devolveu o livro", false);
        multa.inserir(123.92, "Gritou na biblioteca", false);
        System.out.println("Lista de multas:");
        multa.listar();
        multa.atualizar(2L,12.000, "Gritou na biblioteca", true);
        System.out.println("Lista após update:");
        multa.listar();
        multa.excluir(2L);
        System.out.println("Lista de multas:");
        multa.listar();
        multa.listar("devolveu");
        livro.listar("java");
    }
}