package prova01.dao;
import prova01.model.Livro;
import prova01.model.StatusLivro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LivroDao {
    public void inserir(Livro livro){
        String sql = "INSERT INTO livro (titulo, anoPublicacao, autor, statusLivro) values (?,?,?,?)";
        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setString(1, livro.getTitulo());
            stmt.setInt(2, livro.getAnoPublicacao());
            stmt.setString(3, livro.getAutor());
            stmt.setString(4, livro.getStatusLivro().toString());
            stmt.executeUpdate();

        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void atualizar(Livro livro){
        String sql = "UPDATE livro SET titulo = ?, anoPublicacao = ?, autor = ?, statusLivro = ? WHERE id = ?" +
                "";
        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setString(1, livro.getTitulo());
            stmt.setInt(2, livro.getAnoPublicacao());
            stmt.setString(3, livro.getAutor());
            stmt.setString(4, livro.getStatusLivro().toString());
            stmt.setLong(5, livro.getId());
            stmt.executeUpdate();

        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void excluir(Long id){
        String sql = "DELETE FROM livro WHERE id = ?";
        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){
            stmt.setLong(1 ,id);
            stmt.executeUpdate();
        }catch (Exception e){
            throw new RuntimeException(e);
        }

    }

    public List<Livro> listar(){
        List<Livro> lista = new ArrayList<>();

        String sql = "SELECT * FROM livro ORDER BY id";

        try (Connection conexao = ConnectionFactory.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Livro l = new Livro();

                l.setId(rs.getLong("id"));
                l.setTitulo(rs.getString("titulo"));
                l.setAnoPublicacao(rs.getInt("anoPublicacao"));
                l.setAutor(rs.getString("autor"));
                String status = rs.getString("statusLivro").toUpperCase();
                l.setStatusLivro(StatusLivro.valueOf(status));

                lista.add(l);
            }

        } catch(Exception e){
            throw new RuntimeException(e);
        }

        return lista;
    }

    public List<Livro> listar(String parametro){
        List<Livro> lista = new ArrayList<>();
        String sql = "SELECT * FROM livro where titulo like ? ORDER BY titulo";
        try (Connection conexao = ConnectionFactory.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);

        ) {
            stmt.setString(1, "%" + parametro + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Livro l = new Livro();

                l.setId(rs.getLong("id"));
                l.setTitulo(rs.getString("titulo"));
                l.setAnoPublicacao(rs.getInt("anoPublicacao"));
                l.setAutor(rs.getString("autor"));
                String status = rs.getString("statusLivro").toUpperCase();
                l.setStatusLivro(StatusLivro.valueOf(status));

                lista.add(l);
            }
            rs.close();
        }catch(Exception e){
            throw new RuntimeException(e);
        }
        return lista;
    }
}
