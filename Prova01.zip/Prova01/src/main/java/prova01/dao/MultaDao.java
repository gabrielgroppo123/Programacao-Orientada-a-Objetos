package prova01.dao;
import prova01.model.Multa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MultaDao {

    public void inserir(Multa multa){
        String sql = "INSERT INTO multa (valor, motivo, paga) VALUES (?,?, ?)";

        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){

            stmt.setDouble(1, multa.getValor());
            stmt.setString(2, multa.getMotivo());
            stmt.setBoolean(3, multa.getPaga());
            stmt.executeUpdate();

        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void atualizar(Multa multa){
        String sql = "UPDATE multa SET valor = ?, motivo = ?, paga = ? WHERE id = ?";

        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){

            stmt.setDouble(1, multa.getValor());
            stmt.setString(2, multa.getMotivo());
            stmt.setBoolean(3, multa.getPaga());
            stmt.setLong(4, multa.getId());

            stmt.executeUpdate();

        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void excluir(Long id){
        String sql = "DELETE FROM multa WHERE id = ?";

        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql)){

            stmt.setLong(1, id);
            stmt.executeUpdate();

        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public List<Multa> listar(){
        List<Multa> lista = new ArrayList<>();

        String sql = "SELECT * FROM multa ORDER BY id";

        try(Connection conexao = ConnectionFactory.getConnection();
            PreparedStatement stmt = conexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery()){

            while(rs.next()){
                Multa m = new Multa();

                m.setId(rs.getLong("id"));
                m.setValor(rs.getDouble("valor"));
                m.setMotivo(rs.getString("motivo"));
                m.setPaga(rs.getBoolean("paga"));

                lista.add(m);
            }

        } catch (Exception e){
            throw new RuntimeException(e);
        }

        return lista;
    }

    public List<Multa> listar(String parametro){
        List<Multa> lista = new ArrayList<>();

        String sql = "SELECT * FROM multa WHERE motivo LIKE ? ORDER BY motivo";

        try (Connection conexao = ConnectionFactory.getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql);

        ) {
            stmt.setString(1, "%" + parametro + "%");
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                    Multa m = new Multa();

                    m.setId(rs.getLong("id"));
                    m.setValor(rs.getDouble("valor"));
                    m.setMotivo(rs.getString("motivo"));
                    m.setPaga(rs.getBoolean("paga"));

                    lista.add(m);
                }
        rs.close();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }

        return lista;
    }
}