package br.senac.sp.guiarestaurante.models;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class PratoDestaque {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    @ManyToOne
    private TipoPrato tipo;
    private String descricao;
    @ManyToOne
    private Restaurante restaurante;
    private String avaliacao;
    private String foto;
}