package br.senac.sp.guiarestaurante.repository;

import br.senac.sp.guiarestaurante.models.TipoRestaurante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoRestauranteRepository extends JpaRepository<TipoRestaurante, Long> {
    public TipoRestaurante findByNome(String nome);
}
