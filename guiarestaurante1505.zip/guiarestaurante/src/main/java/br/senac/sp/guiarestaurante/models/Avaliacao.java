package br.senac.sp.guiarestaurante.models;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Calendar;

@Data
@Entity
public class Avaliacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String comentario;
    private Calendar data;
    private int nota;
    @ManyToOne
    private Usuario usuario;
    @ManyToOne
    private Restaurante restaurante;
    @ManyToOne(optional = true)
    private PratoDestaque prato;
}
