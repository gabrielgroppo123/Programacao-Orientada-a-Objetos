package br.senac.sp.guiarestaurante.controller;
import br.senac.sp.guiarestaurante.models.Erro;
import br.senac.sp.guiarestaurante.models.TipoRestaurante;
import br.senac.sp.guiarestaurante.service.TipoRestauranteService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;

@RestController
@RequestMapping("/tiporestaurante")
public class TipoRestauranteController {

    private final TipoRestauranteService service;

    public TipoRestauranteController(TipoRestauranteService serv){
        this.service = serv;
    }
    @PostMapping
    public ResponseEntity<Object> inserir(@RequestBody TipoRestaurante tipo){
        try{
            TipoRestaurante salvo = service.inserir(tipo);
            //retornar codigo 201,
            // no header: devolver a location do recurso gerado
            // e no corpo: o recurso gerado
            return ResponseEntity.created(URI.create("/tiporestaurante/" + salvo.getId())).body(salvo);
        }
        catch (DataIntegrityViolationException e){
            Erro erro = Erro.builder().status(HttpStatus.BAD_REQUEST).mensagem("Posivel registro duplicado").exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
        catch (Exception e){
            Erro erro = Erro.builder().status(HttpStatus.INTERNAL_SERVER_ERROR).mensagem("Erro: " + e.getMessage()).exception(e.getClass().getName()).build();
            return new ResponseEntity<Object>(erro, erro.getStatus());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoRestaurante> buscar(@PathVariable ("id") Long id){
        TipoRestaurante tipo = service.buscarPorId(id);
        if (tipo != null){
            return ResponseEntity.ok(tipo);
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<Page<TipoRestaurante>> listar(@PageableDefault(page = 0, size = 10, sort = "nome", direction = Sort.Direction.ASC) Pageable pageable){
        Page<TipoRestaurante>page = service.listarTodos(pageable);
        if (page.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(page);
    }
}
